package com.example.digitkey;

import org.junit.Test;
public class PasswordGeneratorTest {
    @Test
    public void createPasswordNums() {
        System.out.println();
        PasswordGenerator password = new PasswordGenerator("ps1", 20, true, false, false, false);
        password.generatePassword();
        System.out.println("Testing PasswordGenerator(numbers):");
        System.out.println(password.getLabel() + " -> " + password.getPassword());
    }

    @Test
    public void createPasswordLower() {
        System.out.println();
        PasswordGenerator password1 = new PasswordGenerator("ps2", 20, false, false, true, false);
        password1.generatePassword();
        System.out.println("Testing PasswordGenerator(lowercase letters):");
        System.out.println(password1.getLabel() + " -> " + password1.getPassword());
    }

    @Test
    public void createPasswordUpper() {
        System.out.println();
        PasswordGenerator password3 = new PasswordGenerator("ps3", 20, false, true, false, false);
        password3.generatePassword();
        System.out.println("Testing PasswordGenerator(uppercase letters):");
        System.out.println(password3.getLabel() + " -> " + password3.getPassword());
    }

    @Test
    public void createPasswordSpecials() {
        System.out.println();
        PasswordGenerator password4 = new PasswordGenerator("ps4", 20, false, false, false, true);
        password4.generatePassword();
        System.out.println("Testing PasswordGenerator(special characters):");
        System.out.println(password4.getLabel() + " -> " + password4.getPassword());
    }

    @Test
    public void createPasswordAll() {
        System.out.println();
        PasswordGenerator password4 = new PasswordGenerator("ps5", 100, true, true, true, true);
        password4.generatePassword();
        System.out.println("Testing PasswordGenerator(everything):");
        System.out.println(password4.getLabel() + " -> " + password4.getPassword());
    }
}

