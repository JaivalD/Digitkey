package com.example.digitkey;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

public class CreateAccount extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_account);
    }


    public void create(View view) {
        EditText name1 = (EditText) findViewById(R.id.usernameET);
        EditText name2 = (EditText) findViewById(R.id.passwordET);
        EditText name3 = (EditText) findViewById(R.id.passwordCR);
        String n3 = name3.getText().toString();
        String n1 = name1.getText().toString();
        String n2 = name2.getText().toString();
        try {
            FileOutputStream out = openFileOutput("a.txt", Activity.MODE_PRIVATE);
            out.write(n1.length());
            for (int i = 0; i < n1.length(); i++) {
                out.write((int) (n1.charAt(i)));
            }
            out.write(n2.length());
            for (int i = 0; i < n2.length(); i++) {
                out.write((int) (n2.charAt(i)));
            }
            out.flush();
            out.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        if (n2.equals(n3)) {
            Intent i = new Intent(this,
                    MainActivity.class);
            startActivity(i);
        }
    }
}
