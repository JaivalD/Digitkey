package com.example.digitkey;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class Passwords extends AppCompatActivity {
    String pass="";
    String user="";
    String pass2="";
    String user2="";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_passwords);
        try {
            FileInputStream in = openFileInput("password.txt");
            int nameLength = in.read();
            for(int i=0; i<nameLength;i++){
                int data = in.read();
                char letter = (char) data;
                pass+=letter;
            }
            for(int i=0; i<nameLength;i++){
                int data = in.read();
                char letter = (char) data;
                user+=letter;
            }
            in.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        try {
            FileInputStream in = openFileInput("password2.txt");
            int nameLength = in.read();
            for(int i=0; i<nameLength;i++){
                int data = in.read();
                char letter = (char) data;
                pass2+=letter;
            }
            for(int i=0; i<nameLength;i++){
                int data = in.read();
                char letter = (char) data;
                user2+=letter;
            }
            in.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public void pass2(View view) {
            LinearLayout linearLayout = (LinearLayout) findViewById(R.id.linlay);
            TextView user1 = new TextView(this);
            user1.setText("Username:"+user);
            user1.setTextSize(14);
            linearLayout.addView(user1);
            TextView pass1 = new TextView(this);
            pass1.setText("Password:"+pass);
            pass1.setTextSize(14);
            linearLayout.addView(pass1);
    }
    public void pass(View view) {
        LinearLayout linearLayout = (LinearLayout) findViewById(R.id.linlay);
        TextView user = new TextView(this);
        user.setText("Username:"+user2);
        user.setTextSize(14);
        linearLayout.addView(user);
        TextView pass = new TextView(this);
        pass.setText("Password:"+pass2);
        pass.setTextSize(14);
        linearLayout.addView(pass);

    }
    // sends you to main activity screen
    public void home(View view) {
        Intent i = new Intent(this,
                MainActivity.class);
        startActivity(i);
    }

    // sends you to usergenerated screen
    public void add(View view) {
        Intent i = new Intent(this,
                UserGenerated.class);
        startActivity(i);
    }
}