package com.example.digitkey;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class generated extends AppCompatActivity {

    CheckBox cb1, cb2, cb3, cb4;
    String generatedPassword="";
    String usernameStr="";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_generated);
        cb1 = findViewById(R.id.LOWERCASE);
        cb2 = findViewById(R.id.uppercase);
        cb3 = findViewById(R.id.numbers);
        cb4 = findViewById(R.id.special);
    }

    public void generate(View view) {
        boolean lower = false;
        boolean upper = false;
        boolean numbers = false;
        boolean special = false;
        EditText edUsername = (EditText)findViewById(R.id.username);
        String username = (String)edUsername.getText().toString();

        EditText edLength = (EditText)findViewById(R.id.length);
        String length = (String)edLength.getText().toString();

        if (cb1.isChecked()) {
            lower = true;
        }
        if (cb2.isChecked()) {
            upper = true;
        }
        if (cb3.isChecked()) {
            numbers = true;
        }
        if (cb3.isChecked()) {
            special = true;
        }
        PasswordGenerator password = new PasswordGenerator(username, Integer.parseInt(length), numbers, upper, lower, special);
        password.generatePassword();
        usernameStr = password.getLabel();
        generatedPassword = password.getPassword();
        TextView tv = (TextView) findViewById(R.id.password);
        tv.setText(generatedPassword);
    }

    // sends you to home screen
    public void Save(View view) {
        try {
            FileOutputStream out = openFileOutput("password.txt", Activity.MODE_PRIVATE);
            out.write(generatedPassword.length());
            for(int i=0; i <generatedPassword.length();i++){
                out.write((int) (generatedPassword.charAt(i)));}
            out.write(usernameStr.length());
            for(int i=0; i <usernameStr.length();i++){
                out.write((int) (usernameStr.charAt(i)));}
            out.flush();
            out.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }


        Intent i = new Intent(this,
                Passwords.class);
        startActivity(i);
    }

}