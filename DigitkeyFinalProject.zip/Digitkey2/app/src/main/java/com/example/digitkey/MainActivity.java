package com.example.digitkey;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class MainActivity extends AppCompatActivity {
    String username = "";
    String password = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        try {
            FileInputStream in = openFileInput("a.txt");
            int nameLength = in.read();
            for (int i = 0; i < nameLength; i++) {
                int data = in.read();
                char letter = (char) data;
                username += letter;
            }
            nameLength = in.read();
            for (int i = 0; i < nameLength; i++) {
                int data = in.read();
                char letter = (char) data;
                password += letter;
            }
            in.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    // sends you to Createaccount screen
    public void Create(View view) {
        Intent i = new Intent(this,
                CreateAccount.class);
        startActivity(i);
    }

    // sends you to password screen
    public void Login(View view) {
        EditText name1 = (EditText) findViewById(R.id.loginusername);
        EditText name2 = (EditText) findViewById(R.id.loginpassword);
        String n1 = name1.getText().toString();
        String n2 = name2.getText().toString();
        if (n1.equals(username)) {
            if (n2.equals(password)) {
                Intent i = new Intent(this,
                        Passwords.class);
                startActivity(i);
            } else {
                TextView n3 = (TextView) findViewById(R.id.error);
                n3.setText("Error");
            }

        }
    }
}
